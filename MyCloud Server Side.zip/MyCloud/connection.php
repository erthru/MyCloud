<?php

$HOST = 'localhost';
$USER = 'root';
$PASS = '';
$DB = 'mycloud';

$con = mysqli_connect($HOST,$USER,$PASS,$DB) or die('mysql connection failure');

?>
